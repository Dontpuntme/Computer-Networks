# Computer Networks - Project 2

Wireview Program - Connor Mclaughlin and David Martindale

Usage: `./wireview <filename.pcap>`


Authorship document ~p2-authorship.jpeg


Sources: 
http://www.tcpdump.org/manpages/
http://www.tcpdump.org/pcap.html